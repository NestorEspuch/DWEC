// export const SERVER = 'http://localhost:3000';
export const SERVER = 'http://arturober.com:5007';
