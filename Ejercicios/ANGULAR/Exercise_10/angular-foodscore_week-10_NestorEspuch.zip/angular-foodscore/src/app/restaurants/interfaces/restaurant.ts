export interface Restaurant {
  id?: number,
  name: string,
  image: string,
  cuisine: string,
  description: string,
  phone: string,
  daysOpen: string[]
}
