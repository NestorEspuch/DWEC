// export const SERVER = 'http://localhost:3000';
export const SERVER = "http://arturober.com:5010";
export const ARCGIS_TOKEN = "AAPK995b0f2b076a44a7a7521baf6e1a131dKUWODcTBOrS4PyKo5gzw5fW4oejNtboOOAGWqdkTcOoRkwmtoJaivtCeUQ1PSA-g";
export const WEEKDAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
