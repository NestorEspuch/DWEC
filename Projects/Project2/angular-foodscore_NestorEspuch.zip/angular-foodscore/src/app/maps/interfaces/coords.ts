export interface Coords {
  latitude: number;
  longitude: number;
}
