export interface SearchResult {
    address: string;
    latitude: number;
    longitude: number;
}
