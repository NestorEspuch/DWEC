export interface TokenResponse {
  accessToken: string;
}
