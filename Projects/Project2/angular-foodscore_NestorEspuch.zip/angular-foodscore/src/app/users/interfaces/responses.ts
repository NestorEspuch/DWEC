import { User } from "./user";

export interface UsersResponse {
  user: User[];
}

export interface UserResponse {
  user: User;
}
